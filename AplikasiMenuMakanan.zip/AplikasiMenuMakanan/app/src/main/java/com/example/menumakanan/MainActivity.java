package com.example.menumakanan;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recycle;

    String nama[],desk[],harga[];
    int gambar[] = {R.drawable.soto,R.drawable.orakarik,R.drawable.bakso,R.drawable.mieayam,
    R.drawable.nasgor,R.drawable.geprek,R.drawable.ayambakar,R.drawable.capcay};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycle = findViewById(R.id.recycle);

        nama = getResources().getStringArray(R.array.nama);
        desk = getResources().getStringArray(R.array.deskripsi);
        harga = getResources().getStringArray(R.array.harga);

        Madapter madapter = new Madapter(this, nama,desk,harga,gambar);
        recycle.setAdapter(madapter);
        recycle.setLayoutManager(new LinearLayoutManager(this));
    }
}